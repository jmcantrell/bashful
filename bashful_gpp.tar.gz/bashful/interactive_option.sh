#include "interactive_echo.sh"
#ifndef INTERACTIVE_OPTION
#define INTERACTIVE_OPTION
interactive_option() #{{{1
{
    # <doc:interactive_option> {{{
    #
    # Echo the appropriate flag depending on the state of interactive mode.
    #
    # </doc:interactive_option> }}}

    interactive_echo "-i" "-f"
}
#endif
