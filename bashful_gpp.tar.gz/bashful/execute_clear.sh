#ifndef EXECUTE_CLEAR
#define EXECUTE_CLEAR
execute_clear() #{{{1
{
    # <doc:execute_clear> {{{
    #
    # Clear stored commands.
    #
    # Usage: execute_clear
    #
    # </doc:execute_clear> }}}

    unset EXECUTE_CMD
}
#endif
