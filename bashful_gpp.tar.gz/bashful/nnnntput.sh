#ifndef NNNNTPUT
#define NNNNTPUT
#endif
